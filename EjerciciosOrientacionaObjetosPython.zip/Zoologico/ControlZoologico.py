
# Importo las clases necesarias desde sus respectivos módulos
# __import__() lo uso aquí para importación dinámica
Animal = __import__("Animal").Animal
Mamifero = __import__("Mamifero").Mamifero
Ave = __import__("Ave").Ave
Cuidador = __import__("Cuidador").Cuidador
Jaula = __import__("Jaula").Jaula

# Creao el primer cuidador con nombre y años de experiencia
cuidador1 = Cuidador("Camilo", 7)

# Creo tres animales diferentes
# Mamifero(nombre, edad, especie, tipo_pelaje)
# Ave(nombre, edad, tipo_ave, envergadura_alas)

Animal1 = Mamifero("Oso de Anteojos", 6, "Andino", "Largo y negro")
Animal2 = Mamifero("Jaguar", 5, "Africano", "Manchado")
Animal3 = Ave("Cóndor de los Andes", 8, "Cóndor", 3.2)

# Creo la jaula con número, lista de animales y cuidador asignado
# Composición: la jaula "tiene" animales y un cuidador

jaula1 = Jaula(1, [Animal1, Animal2, Animal3], cuidador1)

# se muestra la informacion del zoologico
print("=== INFORMACIÓN DEL ZOOLÓGICO ===")
print(f"Número de jaula: {jaula1.get_numero()}")
print(f"Cuidador: {jaula1.get_cuidador().get_nombre_cuidador()}")
print(f"Años de experiencia: {jaula1.get_cuidador().get_years_exp()}")
#se muestra la informacion del oso de anteojos
print("\n--- Oso de Anteojos ---")
print(f"Nombre: {Animal1.get_nombre()}")
print(f"Edad: {Animal1.get_edad()}")
print(f"Especie: {Animal1.get_especie()}")
print(f"Tipo de pelaje: {Animal1.get_tipo_pelaje()}")
# se muestra la informacion del Jagur
print("\n--- Jaguar ---")
print(f"Nombre: {Animal2.get_nombre()}")
print(f"Edad: {Animal2.get_edad()}")
print(f"Especie: {Animal2.get_especie()}")
print(f"Tipo de pelaje: {Animal2.get_tipo_pelaje()}")
# se muestra la infromacion del condor

print("\n--- Cóndor ---")
print(f"Nombre: {Animal3.get_nombre()}")
print(f"Edad: {Animal3.get_edad()}")
print(f"Envergadura: {Animal3.get_alas()} metros")
 # se muestran los comportamientos de los animales  (polimorfismo)   
print("\n=== COMPORTAMIENTOS ===")
Animal1.hacer_sonido()
Animal1.comer()
Animal1.amamantar()

Animal2.hacer_sonido()
Animal2.comer()
Animal2.amamantar()

Animal3.volar()

# se muestran las operacion es  al crear  nuevo cuidador, nuevo animal y se le asigna una jaula al nuevo, retirando al jaguar
print("\n=== OPERACIONES DE JAULA ===")
cuidador2 = Cuidador("Valentina", 5)
jaula1.asignar_cuidador(cuidador2)

Animal4 = Mamifero("Mono Araña", 3, "Ateles", "Negro")
jaula1.asignar_animal(Animal4)

jaula1.retirar_animal(Animal2)

print(f"\nNuevo cuidador: {jaula1.get_cuidador().get_nombre_cuidador()}")