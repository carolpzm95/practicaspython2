from abc import ABC, abstractmethod

class Forma(ABC):

    def __init__(self, color):
        self._color = color
        self._area = 0.0
    

    def get_color(self):
        return self._color
    
    def set_color(self, color):
        self._color = color
    

    def get_area(self):
        return self._area
    
    @abstractmethod
    def _calcularArea(self):
        pass
    def mostrar_info(self):
        print(f"Forma de color: {self._color}")
        print(f"Area: {self._area:.2f} unidades²")