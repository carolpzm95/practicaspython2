Cuenta = __import__("Cuenta").Cuenta
cuenta1 = Cuenta("001-123456", "Carolina", 500000, "2025-11-14")

print(f"titular: {cuenta1.get_titular()}")
print(f"Saldo: ${cuenta1.get_saldo()}")

cuenta1.DepositarDinero(100000)

cuenta1.RetirarDinero(50000)

print(f"Saldo final: ${cuenta1.get_saldo()}")