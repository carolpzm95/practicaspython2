class Cuenta:
    def __init__(self,NumeroCuenta, titular, saldo, fecha):
        self._titular = titular
        self._saldo = saldo
        self._fecha = fecha
        self._NumeroCuenta=NumeroCuenta
    def set_NumeroCuenta(self,NumeroCuenta):
        self._NumeroCuenta=NumeroCuenta

    def set_titular(self, titular):
        self._titular = titular

    def set_saldo(self, saldo):
        self._saldo = saldo

    def set_fecha(self, fecha):
        self._fecha = fecha
    
    def get_NumeroCuenta(self):
        return self._NumeroCuenta
    def get_titular(self):
        return self._titular
    
    def get_saldo(self):
        return self._saldo
    
    def get_fecha(self):
        return self._fecha
     
    def DepositarDinero(self,monto):
        if (monto<=0):
            print("el monto a depositar debe ser mayor a 0")
            return
        else:
           self._saldo+=monto
           print(f"deposito de{monto} realizado con exito,saldo actual {self._saldo}")

    def RetirarDinero (self,monto,):
        if (monto>self._saldo):
            print(f"saldo insuficiente,saldo actual {self._saldo}")
            return
        else:
           self._saldo-=monto
        print(f"retiro de {monto} realizado con exito,saldo actual{self._saldo}")
