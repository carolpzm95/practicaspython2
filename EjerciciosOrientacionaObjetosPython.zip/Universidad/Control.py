Curso = __import__("Curso").Curso
Estudiante = __import__("Estudiante").Estudiante

estudiante1 = Estudiante("Carolina Lopez", "E001", "Derecho,")
estudiante2 = Estudiante("Jacobo Gaviria", "E002", "AnalisisYDesarrolloDeSoftware,")

curso1 = Curso("Derecho", "C001", 3,[])
curso2 = Curso("AnalisisYDesarrolloDeSoftware", "C002", 4,[])

curso1.agregarEstudiantes(estudiante1)
curso1.agregarEstudiantes(estudiante2)
curso2.agregarEstudiantes(estudiante1)

#Impresion

print("===ESTUDIANTES===")
print(f"{estudiante1._nombre} - {estudiante1._codigoEstudiantil}")
print(f"Cursos matriculados: {len(estudiante1._cursosMatriculados)}")

print(f"\n{estudiante2._nombre} - {estudiante2._codigoEstudiantil}")
print(f"Cursos matriculados: {len(estudiante2._cursosMatriculados)}")

print("\n=== CURSOS ===")
print(f"{curso1.get_nombre()} ({curso1.get_codigo()}) - Créditos: {curso1.get_numCreditos()}")
print(f"{curso2.get_nombre()} ({curso2.get_codigo()}) - Créditos: {curso2.get_numCreditos()}")