from Vehiculos import Vehiculos
from VehiculosTerrestres import VehiculosTerrestres
from VehiculosAcuaticos import VehiculosAcuaticos

#VEHICULOS TERRESTRES

print("=" * 50)
print("Vehiculos Terrestres")
print("=" * 50)

moto1 = VehiculosTerrestres("Auteco", "Victory One", "2 Personas", 2)
moto2 = VehiculosTerrestres("AKT", "NKD 125", "2 Personas", 2)

carro1 = VehiculosTerrestres("Chevrolet", "Spark GT", "5 Personas", 4)
carro2 = VehiculosTerrestres("Mazda 2", "Sedan", "5 Personas", 4)

camioneta1 = VehiculosTerrestres("Chevrolet", "D-Max", "5 Personas", 4)
camioneta2 = VehiculosTerrestres("Toyota", "Hilux", "5 Personas", 4)

bus1 = VehiculosTerrestres("Chevrolet", "NPR Euro", "60 Personas", 6)
bus2 = VehiculosTerrestres("Hino", "FC", "30 Personas", 6)

#VEHICULOS ACUATICOS

print("\n" + "= " * 50)
print("Vehiculos Acuaticos")
print("=" * 50)

lancha1 = VehiculosAcuaticos("Fibratec", "FL-600", "8 Personas", "Motor fuera de borda Yamaha")

yate1 = VehiculosAcuaticos("Ferretti", "550", "12 Personas", "Motor diésel MAN")

barco = VehiculosAcuaticos("Ferry Caribe", "Santa Marta Express", "150 Personas", "Sistema diésel-eléctrico")

print("\n" + "= " * 50)
print("DEMOSTRACIONES")
print("=" * 50)

moto1.mostrar_info()
moto1.manejar()
moto1.frenar()
moto1.moverse()

print()
bus1.mostrar_info()
bus1.manejar()
bus1.frenar()
bus1.moverse()

print()
lancha1.mostrar_info()
lancha1.moverse()
lancha1.manejar()
lancha1.anclar()

print()
yate1.mostrar_info()
yate1.moverse()
yate1.anclar()
yate1.manejar()

print("\n" + "= " * 50)
print("TODOS LOS VEHICULOS CREADOS EXITOSAMENTE")
print("=" * 50)