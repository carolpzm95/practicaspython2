class EquipoFutbol:
    def __init__(self, nombre, ciudad, entrenador):
        self._nombre = nombre
        self._ciudad = ciudad
        self._entrenador = entrenador
        self._jugadores = []
    
    def set_nombre(self, nombre):
        self._nombre = nombre
    
    def set_ciudad(self, ciudad):
        self._ciudad = ciudad
    
    def set_entrenador(self, entrenador):
        self._entrenador = entrenador
    
    def set_jugadores(self, jugadores):
        self._jugadores = jugadores
    
    def get_nombre(self):
        return self._nombre
    
    def get_ciudad(self):
        return self._ciudad
    
    def get_entrenador(self):
        return self._entrenador
    
    def get_jugadores(self):
        return self._jugadores
    
    def agregar(self, jugador):
        self._jugadores.append(jugador)
    
    def remover(self, jugador):
        self._jugadores.remove(jugador)
    
    def mostrar(self):
        print(f"\nEquipo: {self._nombre}")
        print(f"Ciudad: {self._ciudad}")
        print(f"Entrenador: {self._entrenador}")
        print("Jugadores:")
        for jugador in self._jugadores:
            print(f"  {jugador}")