class Jugadores:
    def __init__(self,nombre,edad,posicion,NumCamisa):
        self._nombre=nombre
        self._edad=edad
        self._posicion=posicion
        self._NumCamisa=NumCamisa
    def set_nombre(self, nombre):
        self._nombre = nombre
        
    def set_posicion(self, posicion):
        self._posicion = posicion
    def set_edad(self, edad):
        if edad > 0:
            self._edad = edad
        else:
            print("Error: La edad debe ser positiva")
    def set_NumCamisa(self, NumCamisa):
        self._NumCamisa= NumCamisa
    def transferir(self):
        
        print(f"{self._nombre} ha sido transferido")
    
    def __str__(self):
        return f"#{self._NumCamisa} - {self._nombre} ({self._posicion}) - {self._edad} años"
    def get_nombre(self):
        return self._nombre
    def get_posicion(self):
        return self._posicion
    def get_edad(self):
        return self._edad
    def get_Numcamisa(self):
        return self._NumCamisa