from Cliente import Cliente
from Productos import Productos
from Pedido import Pedido


print("=" * 30)
print("====SISTEMA DE PEDIDOS====")
print("=" * 30)

cliente1 = Cliente("Carolina López", "lilicaro95@hotmail.com", 3135170294)
cliente2 = Cliente("Zully Moreno", "zumorena65@hotmail.com", 3166904062)

producto1 = Productos("iphone 17 pro max", "E0021", 4000000)
producto2 = Productos("Samsung q led", "A098", 3300000)

pedido1 = Pedido(cliente1, producto2, "16/11/2025")
pedido2 = Pedido(cliente2, producto1, "17/11/2025")

pedido1.mostrarPedido()
pedido2.mostrarPedido()