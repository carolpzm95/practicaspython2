-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-12-2025 a las 23:57:06
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inder_e_sports`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comuna_barrio`
--

CREATE TABLE `comuna_barrio` (
  `id` int(11) NOT NULL,
  `COMUNA` varchar(45) NOT NULL,
  `barrio` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `comuna_barrio`
--

INSERT INTO `comuna_barrio` (`id`, `COMUNA`, `barrio`) VALUES
(1, 'Comuna 1', 'La Candelaria'),
(2, 'Comuna 1', 'Las Aguas'),
(3, 'Comuna 2', 'Santa Inés'),
(4, 'Comuna 2', 'La Macarena'),
(5, 'Comuna 3', 'Sagrado Corazón'),
(6, 'Comuna 3', 'San Martín'),
(7, 'Comuna 4', 'San Cristóbal'),
(8, 'Comuna 4', '20 de Julio'),
(9, 'Comuna 5', 'Lourdes'),
(10, 'Comuna 5', 'Muzu'),
(11, 'Comuna 6', 'Tunjuelito'),
(12, 'Comuna 6', 'Venecia'),
(13, 'Comuna 7', 'Bosa Central'),
(14, 'Comuna 7', 'El Porvenir'),
(15, 'Comuna 8', 'Kennedy Central'),
(16, 'Comuna 8', 'Bavaria'),
(17, 'Comuna 9', 'Fontibón'),
(18, 'Comuna 9', 'Modelia'),
(19, 'Comuna 10', 'Engativá'),
(20, 'Comuna 10', 'Minuto de Dios'),
(21, 'Popular', 'Santo Domingo Savio'),
(22, 'Popular', 'Popular 1'),
(23, 'Popular', 'Granizal'),
(24, 'Santa Cruz', 'Santa Cruz'),
(25, 'Santa Cruz', 'La Rosa'),
(26, 'Santa Cruz', 'Moscú No. 1'),
(27, 'Manrique', 'Manrique Central'),
(28, 'Manrique', 'Las Granjas'),
(29, 'Manrique', 'Campo Valdés'),
(30, 'Aranjuez', 'Aranjuez'),
(31, 'Aranjuez', 'Berlin'),
(32, 'Aranjuez', 'San Isidro'),
(33, 'Castilla', 'Castilla'),
(34, 'Castilla', 'Pedregal'),
(35, 'Castilla', 'Doce de Octubre'),
(36, 'Doce de Octubre', 'Santander'),
(37, 'Doce de Octubre', 'Picacho'),
(38, 'Robledo', 'Robledo'),
(39, 'Robledo', 'El Volador'),
(40, 'Robledo', 'San German'),
(41, 'Villa Hermosa', 'Villa Hermosa'),
(42, 'Villa Hermosa', 'La Mansión'),
(43, 'Buenos Aires', 'Buenos Aires'),
(44, 'Buenos Aires', 'Caicedo'),
(45, 'La Candelaria', 'Prado'),
(46, 'La Candelaria', 'Boston'),
(47, 'La Candelaria', 'San Benito'),
(48, 'Laureles-Estadio', 'Laureles'),
(49, 'Laureles-Estadio', 'Estadio'),
(50, 'Laureles-Estadio', 'San Joaquin'),
(51, 'La América', 'La América'),
(52, 'La América', 'Calasanz'),
(53, 'San Javier', 'San Javier'),
(54, 'San Javier', 'El Socorro'),
(55, 'El Poblado', 'El Poblado'),
(56, 'El Poblado', 'Manila'),
(57, 'El Poblado', 'Astorga'),
(58, 'Guayabal', 'Guayabal'),
(59, 'Guayabal', 'Trinidad'),
(60, 'Belén', 'Belén'),
(61, 'Belén', 'Rosales'),
(62, 'Belén', 'Fatima');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consola`
--

CREATE TABLE `consola` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `numero_serie` varchar(45) NOT NULL,
  `existencia_inventario` int(11) NOT NULL,
  `dir_ip` varchar(45) DEFAULT NULL,
  `dir_mac` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `consola`
--

INSERT INTO `consola` (`id`, `nombre`, `numero_serie`, `existencia_inventario`, `dir_ip`, `dir_mac`) VALUES
(1, 'PlayStation 5', 'PS5-CFI-1015A-001', 15, '192.168.1.10', '00:1B:44:11:3A:B7'),
(2, 'Xbox Series X', 'XSX-RRT-00001-2021', 8, '192.168.1.11', '00:50:F2:35:87:CB'),
(3, 'Nintendo Switch', 'NSW-HAC-001-XAW', 25, '192.168.1.12', '98:B6:E9:49:00:01'),
(4, 'PlayStation 4 Pro', 'PS4-CUH-7215B-1TB', 12, '192.168.1.13', '7C:C3:A1:B5:2E:9F'),
(5, 'Xbox One X', 'XBX-PROJECT-SCORPIO', 6, '192.168.1.14', '28:18:78:FF:D2:1A'),
(6, 'Nintendo Switch OLED', 'NSW-HEG-001-OLED', 18, '192.168.1.15', '98:B6:E9:7A:12:34'),
(7, 'Steam Deck', 'SD-256GB-V010101', 10, '192.168.1.16', '02:00:4C:4F:4F:50'),
(8, 'PlayStation 5 Digital', 'PS5-CFI-1015B-DE', 9, '192.168.1.17', '00:1B:44:11:7C:D8'),
(9, 'Xbox Series S', 'XSS-RRS-00001-2020', 14, '192.168.1.18', '00:50:F2:35:9A:EF'),
(10, 'Retroid Pocket 3+', 'RP3P-4GB-128GB-001', 22, '192.168.1.19', 'A0:36:9F:12:8B:45'),
(11, 'Consola 1', 'SN1001', 1, '192.168.1.1', 'AA:BB:CC:DD:EE:01'),
(12, 'Consola 2', 'SN1002', 1, '192.168.1.2', 'AA:BB:CC:DD:EE:02'),
(13, 'Consola 3', 'SN1003', 1, '192.168.1.3', 'AA:BB:CC:DD:EE:03'),
(14, 'Consola 4', 'SN1004', 1, '192.168.1.4', 'AA:BB:CC:DD:EE:04'),
(15, 'Consola 5', 'SN1005', 1, '192.168.1.5', 'AA:BB:CC:DD:EE:05'),
(16, 'Consola 6', 'SN1006', 1, '192.168.1.6', 'AA:BB:CC:DD:EE:06'),
(17, 'Consola 7', 'SN1007', 1, '192.168.1.7', 'AA:BB:CC:DD:EE:07'),
(18, 'Consola 8', 'SN1008', 1, '192.168.1.8', 'AA:BB:CC:DD:EE:08'),
(19, 'Consola 9', 'SN1009', 1, '192.168.1.9', 'AA:BB:CC:DD:EE:09'),
(20, 'Consola 10', 'SN1010', 1, '192.168.1.10', 'AA:BB:CC:DD:EE:0a'),
(21, 'Consola 11', 'SN1011', 1, '192.168.1.11', 'AA:BB:CC:DD:EE:0b'),
(22, 'Consola 12', 'SN1012', 1, '192.168.1.12', 'AA:BB:CC:DD:EE:0c'),
(23, 'Consola 13', 'SN1013', 1, '192.168.1.13', 'AA:BB:CC:DD:EE:0d'),
(24, 'Consola 14', 'SN1014', 1, '192.168.1.14', 'AA:BB:CC:DD:EE:0e'),
(25, 'Consola 15', 'SN1015', 1, '192.168.1.15', 'AA:BB:CC:DD:EE:0f'),
(26, 'Consola 16', 'SN1016', 1, '192.168.1.16', 'AA:BB:CC:DD:EE:10'),
(27, 'Consola 17', 'SN1017', 1, '192.168.1.17', 'AA:BB:CC:DD:EE:11'),
(28, 'Consola 18', 'SN1018', 1, '192.168.1.18', 'AA:BB:CC:DD:EE:12'),
(29, 'Consola 19', 'SN1019', 1, '192.168.1.19', 'AA:BB:CC:DD:EE:13'),
(30, 'Consola 20', 'SN1020', 1, '192.168.1.20', 'AA:BB:CC:DD:EE:14'),
(31, 'Consola 21', 'SN1021', 1, '192.168.1.21', 'AA:BB:CC:DD:EE:15'),
(32, 'Consola 22', 'SN1022', 1, '192.168.1.22', 'AA:BB:CC:DD:EE:16'),
(33, 'Consola 23', 'SN1023', 1, '192.168.1.23', 'AA:BB:CC:DD:EE:17'),
(34, 'Consola 24', 'SN1024', 1, '192.168.1.24', 'AA:BB:CC:DD:EE:18'),
(35, 'Consola 25', 'SN1025', 1, '192.168.1.25', 'AA:BB:CC:DD:EE:19'),
(36, 'Consola 26', 'SN1026', 1, '192.168.1.26', 'AA:BB:CC:DD:EE:1a'),
(37, 'Consola 27', 'SN1027', 1, '192.168.1.27', 'AA:BB:CC:DD:EE:1b'),
(38, 'Consola 28', 'SN1028', 1, '192.168.1.28', 'AA:BB:CC:DD:EE:1c'),
(39, 'Consola 29', 'SN1029', 1, '192.168.1.29', 'AA:BB:CC:DD:EE:1d'),
(40, 'Consola 30', 'SN1030', 1, '192.168.1.30', 'AA:BB:CC:DD:EE:1e');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `control`
--

CREATE TABLE `control` (
  `id` int(11) NOT NULL,
  `numero_serie` varchar(45) DEFAULT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `CONSOLA_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `control`
--

INSERT INTO `control` (`id`, `numero_serie`, `tipo`, `CONSOLA_id`) VALUES
(1, 'DS5-CFI-ZCT1W-001', 'DualSense Wireless', 1),
(2, 'DS5-CFI-ZCT1W-002', 'DualSense Wireless', 1),
(3, 'XWC-1914-BLK-001', 'Xbox Wireless Controller', 2),
(4, 'XWC-1914-WHT-002', 'Xbox Wireless Controller', 2),
(5, 'JCL-003-GRY-L001', 'Joy-Con Left', 3),
(6, 'JCR-003-GRY-R001', 'Joy-Con Right', 3),
(7, 'PRO-HAC-013-001', 'Pro Controller', 3),
(8, 'DS4-CUH-ZCT2U-BLK', 'DualShock 4', 4),
(9, 'DS4-CUH-ZCT2U-BLU', 'DualShock 4', 4),
(10, 'XO1-1708-BLK-001', 'Xbox One Controller', 5),
(11, 'XO1-1708-WHT-002', 'Xbox One Controller', 5),
(12, 'JCL-003-NEO-L002', 'Joy-Con Left Neon', 6),
(13, 'JCR-003-NEO-R002', 'Joy-Con Right Neon', 6),
(14, 'SD-CTL-001-LEFT', 'Steam Controller Left', 7),
(15, 'SD-CTL-001-RIGHT', 'Steam Controller Right', 7),
(16, 'DS5-CFI-ZCT1W-003', 'DualSense Wireless', 8),
(17, 'DS5-CFI-ZCT1W-004', 'DualSense Wireless', 8),
(18, 'XSS-1914-WHT-001', 'Xbox Wireless Controller', 9),
(19, 'XSS-1914-BLK-002', 'Xbox Wireless Controller', 9),
(20, 'RP3P-CTL-001-USB', 'Retroid USB Controller', 10),
(21, 'CTRL1001', 'Inalambrico', 2),
(22, 'CTRL1002', 'Inalambrico', 3),
(23, 'CTRL1003', 'Inalambrico', 4),
(24, 'CTRL1004', 'Inalambrico', 5),
(25, 'CTRL1005', 'Inalambrico', 6),
(26, 'CTRL1006', 'Inalambrico', 7),
(27, 'CTRL1007', 'Inalambrico', 8),
(28, 'CTRL1008', 'Inalambrico', 9),
(29, 'CTRL1009', 'Inalambrico', 10),
(30, 'CTRL1010', 'Inalambrico', 11),
(31, 'CTRL1011', 'Inalambrico', 12),
(32, 'CTRL1012', 'Inalambrico', 13),
(33, 'CTRL1013', 'Inalambrico', 14),
(34, 'CTRL1014', 'Inalambrico', 15),
(35, 'CTRL1015', 'Inalambrico', 16),
(36, 'CTRL1016', 'Inalambrico', 17),
(37, 'CTRL1017', 'Inalambrico', 18),
(38, 'CTRL1018', 'Inalambrico', 19),
(39, 'CTRL1019', 'Inalambrico', 20),
(40, 'CTRL1020', 'Inalambrico', 21),
(41, 'CTRL1021', 'Inalambrico', 22),
(42, 'CTRL1022', 'Inalambrico', 23),
(43, 'CTRL1023', 'Inalambrico', 24),
(44, 'CTRL1024', 'Inalambrico', 25),
(45, 'CTRL1025', 'Inalambrico', 26),
(46, 'CTRL1026', 'Inalambrico', 27),
(47, 'CTRL1027', 'Inalambrico', 28),
(48, 'CTRL1028', 'Inalambrico', 29),
(49, 'CTRL1029', 'Inalambrico', 30),
(50, 'CTRL1030', 'Inalambrico', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo_juego`
--

CREATE TABLE `equipo_juego` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `horas` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `juego` varchar(45) DEFAULT NULL,
  `JUEGO_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `equipo_juego`
--

INSERT INTO `equipo_juego` (`id`, `nombre`, `horas`, `nivel`, `juego`, `JUEGO_id`) VALUES
(2, 'Thunder Wolves', 203, 52, 'Call of Duty MW3', 2),
(3, 'Pixel Warriors', 89, 28, 'Fortnite', 3),
(4, 'Shadow Hunters', 312, 67, 'League of Legends', 4),
(5, 'Fire Eagles', 178, 41, 'Counter-Strike 2', 5),
(6, 'Ice Breakers', 145, 38, 'FIFA 24', 1),
(7, 'Storm Raiders', 267, 58, 'Apex Legends', 6),
(8, 'Golden Lions', 194, 47, 'Valorant', 7),
(9, 'Night Owls', 223, 53, 'Rocket League', 8),
(10, 'Steel Titans', 98, 32, 'Overwatch 2', 9),
(11, 'Cyber Spartans', 341, 72, 'Dota 2', 10),
(12, 'Red Panthers', 167, 43, 'Call of Duty MW3', 2),
(13, 'Blue Sharks', 125, 36, 'Fortnite', 3),
(14, 'Green Vipers', 289, 61, 'League of Legends', 4),
(15, 'White Ravens', 156, 39, 'Counter-Strike 2', 5),
(16, 'Black Hawks', 201, 49, 'Apex Legends', 6),
(17, 'Silver Wolves', 134, 35, 'Valorant', 7),
(18, 'Purple Phoenixes', 245, 56, 'Rocket League', 8),
(19, 'Orange Tigers', 112, 33, 'Overwatch 2', 9),
(20, 'Pink Unicorns', 298, 64, 'Dota 2', 10),
(21, 'Equipo 1', 590, 25, 'Juego 2', 2),
(22, 'Equipo 2', 805, 46, 'Juego 3', 3),
(23, 'Equipo 3', 25, 1, 'Juego 4', 4),
(24, 'Equipo 4', 537, 30, 'Juego 5', 5),
(25, 'Equipo 5', 583, 29, 'Juego 6', 6),
(26, 'Equipo 6', 480, 45, 'Juego 7', 7),
(27, 'Equipo 7', 106, 91, 'Juego 8', 8),
(28, 'Equipo 8', 942, 32, 'Juego 9', 9),
(29, 'Equipo 9', 393, 96, 'Juego 10', 10),
(30, 'Equipo 10', 218, 18, 'Juego 11', 11),
(31, 'Equipo 11', 32, 43, 'Juego 12', 12),
(32, 'Equipo 12', 652, 61, 'Juego 13', 13),
(33, 'Equipo 13', 985, 31, 'Juego 14', 14),
(34, 'Equipo 14', 814, 26, 'Juego 15', 15),
(35, 'Equipo 15', 918, 60, 'Juego 16', 16),
(36, 'Equipo 16', 293, 72, 'Juego 17', 17),
(37, 'Equipo 17', 436, 38, 'Juego 18', 18),
(38, 'Equipo 18', 386, 36, 'Juego 19', 19),
(39, 'Equipo 19', 121, 81, 'Juego 20', 20),
(40, 'Equipo 20', 578, 94, 'Juego 21', 21),
(41, 'Equipo 21', 966, 91, 'Juego 22', 22),
(42, 'Equipo 22', 672, 89, 'Juego 23', 23),
(43, 'Equipo 23', 399, 57, 'Juego 24', 24),
(44, 'Equipo 24', 606, 33, 'Juego 25', 25),
(45, 'Equipo 25', 711, 35, 'Juego 26', 26),
(46, 'Equipo 26', 471, 25, 'Juego 27', 27),
(47, 'Equipo 27', 831, 79, 'Juego 28', 28),
(48, 'Equipo 28', 807, 82, 'Juego 29', 29),
(49, 'Equipo 29', 110, 36, 'Juego 30', 30),
(50, 'Equipo 30', 298, 60, 'Juego 1', 1),
(0, 'Camilo', 1, 1, NULL, 99);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juego`
--

CREATE TABLE `juego` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `clasificiacion_ESRB` varchar(45) DEFAULT NULL,
  `estudio_dev` varchar(45) DEFAULT NULL,
  `plataformas_disponibles` varchar(45) DEFAULT NULL,
  `numero_jugadores` varchar(45) DEFAULT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `existencias_inventario` int(11) DEFAULT NULL,
  `PLATAFORMA_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `juego`
--

INSERT INTO `juego` (`id`, `nombre`, `clasificiacion_ESRB`, `estudio_dev`, `plataformas_disponibles`, `numero_jugadores`, `tipo`, `existencias_inventario`, `PLATAFORMA_id`) VALUES
(2, 'Call of Duty Modern Warfare III', 'M', 'Activision', 'PS5, Xbox Series X/S, PC', '1-32 Online', 'Shooter', 38, 2),
(3, 'The Legend of Zelda: Tears Kingdom', 'E10+', 'Nintendo EPD', 'Nintendo Switch', '1 Jugador', 'Aventura', 52, 3),
(4, 'Spider-Man 2', 'T', 'Insomniac Games', 'PlayStation 5', '1 Jugador', 'Acción', 29, 1),
(5, 'Super Mario Bros. Wonder', 'E', 'Nintendo EPD', 'Nintendo Switch', '1-4 Local', 'Plataformas', 41, 3),
(6, 'Forza Motorsport', 'E', 'Turn 10 Studios', 'Xbox Series X/S, PC', '1-24 Online', 'Carreras', 33, 2),
(7, 'Baldurs Gate 3', 'M', 'Larian Studios', 'PS5, Xbox Series X/S, PC', '1-4 Local/Online', 'RPG', 27, 4),
(8, 'Hogwarts Legacy', 'T', 'Portkey Games', 'PS5, Xbox Series X/S, Switch', '1 Jugador', 'RPG', 36, 1),
(9, 'Mortal Kombat 1', 'M', 'NetherRealm Studios', 'PS5, Xbox Series X/S, Switch', '1-2 Local, Online', 'Lucha', 24, 1),
(10, 'Starfield', 'M', 'Bethesda Game Studios', 'Xbox Series X/S, PC', '1 Jugador', 'RPG', 31, 2),
(11, 'Cyberpunk 2077', 'M', 'CD Projekt RED', 'PS5, Xbox Series X/S, PC', '1 Jugador', 'RPG', 19, 4),
(12, 'Gran Turismo 7', 'E', 'Polyphony Digital', 'PlayStation 5, PS4', '1-20 Online', 'Carreras', 28, 1),
(13, 'Halo Infinite', 'T', '343 Industries', 'Xbox Series X/S, PC', '1-24 Online', 'Shooter', 22, 2),
(14, 'Mario Kart 8 Deluxe', 'E', 'Nintendo EPD', 'Nintendo Switch', '1-4 Local, 1-12 Online', 'Carreras', 47, 3),
(15, 'God of War Ragnarök', 'M', 'Santa Monica Studio', 'PlayStation 5, PS4', '1 Jugador', 'Acción', 35, 1),
(16, 'Minecraft', 'E10+', 'Mojang Studios', 'Todas las plataformas', '1-8 Local, Ilimitado Online', 'Sandbox', 54, 5),
(17, 'Assassins Creed Mirage', 'M', 'Ubisoft Bordeaux', 'PS5, Xbox Series X/S, PC', '1 Jugador', 'Acción', 26, 4),
(18, 'Dead Space Remake', 'M', 'Motive Studio', 'PS5, Xbox Series X/S, PC', '1 Jugador', 'Terror', 18, 1),
(19, 'Street Fighter 6', 'T', 'Capcom', 'PS5, Xbox Series X/S, PC', '1-2 Local, Online', 'Lucha', 32, 1),
(20, 'Tears of the Kingdom', 'E10+', 'Nintendo EPD', 'Nintendo Switch', '1 Jugador', 'Aventura', 43, 3),
(21, 'League of Legends', 'T', 'Riot Games', 'PC', '5v5', 'MOBA', 19, 1),
(22, 'Valorant', 'T', 'Riot Games', 'PC', '5v5', 'Shooter', 19, 2),
(23, 'FIFA 24', 'E', 'EA Sports', 'Multi', '1v1', 'Deportes', 18, 3),
(24, 'Call of Duty', 'M', 'Activision', 'Multi', 'Multi', 'Shooter', 16, 4),
(25, 'Fortnite', 'T', 'Epic Games', 'Multi', '100', 'Battle Royale', 11, 5),
(26, 'Minecraft', 'E', 'Mojang', 'Multi', 'Multi', 'Sandbox', 17, 6),
(27, 'Overwatch 2', 'T', 'Blizzard', 'Multi', '5v5', 'Shooter', 12, 7),
(28, 'CS:GO 2', 'M', 'Valve', 'PC', '5v5', 'Shooter', 5, 8),
(29, 'Dota 2', 'T', 'Valve', 'PC', '5v5', 'MOBA', 19, 9),
(30, 'Rocket League', 'E', 'Psyonix', 'Multi', '3v3', 'Deportes', 5, 10),
(31, 'Street Fighter 6', 'T', 'Capcom', 'Multi', '1v1', 'Lucha', 13, 1),
(32, 'Tekken 8', 'T', 'Bandai Namco', 'Multi', '1v1', 'Lucha', 4, 2),
(33, 'Super Smash Bros', 'E', 'Nintendo', 'Switch', '1v1', 'Lucha', 10, 3),
(34, 'Mario Kart 8', 'E', 'Nintendo', 'Switch', 'Multi', 'Carreras', 9, 4),
(35, 'Apex Legends', 'T', 'Respawn', 'Multi', '60', 'Battle Royale', 8, 5),
(36, 'PUBG', 'M', 'Krafton', 'Multi', '100', 'Battle Royale', 11, 6),
(37, 'Rainbow Six Siege', 'M', 'Ubisoft', 'Multi', '5v5', 'Shooter', 13, 7),
(38, 'Among Us', 'E', 'Innersloth', 'Multi', '10', 'Social', 16, 8),
(39, 'Fall Guys', 'E', 'Mediatonic', 'Multi', '60', 'Platformer', 16, 9),
(40, 'Genshin Impact', 'T', 'HoYoverse', 'Multi', '1', 'RPG', 1, 10),
(41, 'Clash Royale', 'E', 'Supercell', 'Mobile', '1v1', 'Estrategia', 7, 1),
(42, 'Free Fire', 'M', 'Garena', 'Mobile', '50', 'Battle Royale', 1, 2),
(43, 'Brawl Stars', 'E', 'Supercell', 'Mobile', '3v3', 'Accion', 16, 3),
(44, 'Pokemon Unite', 'E', 'Pokemon Co', 'Multi', '5v5', 'MOBA', 20, 4),
(45, 'Halo Infinite', 'M', '343 Ind', 'Xbox/PC', '4v4', 'Shooter', 3, 5),
(46, 'Forza Horizon 5', 'E', 'Playground', 'Xbox/PC', 'Multi', 'Carreras', 3, 6),
(47, 'Gran Turismo 7', 'E', 'Polyphony', 'PS', 'Multi', 'Carreras', 8, 7),
(0, 'Camilo', NULL, 'EA', NULL, NULL, 'Terror', NULL, 0),
(0, 'Camilo2', NULL, '1', NULL, NULL, '1', NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logro_trofeo`
--

CREATE TABLE `logro_trofeo` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `puntos_req` int(11) NOT NULL,
  `JUEGO_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `logro_trofeo`
--

INSERT INTO `logro_trofeo` (`id`, `nombre`, `puntos_req`, `JUEGO_id`) VALUES
(1, 'Primer Gol', 100, 1),
(2, 'Hat-trick Legendario', 500, 1),
(3, 'Primera Muerte', 50, 2),
(4, 'Francotirador Experto', 750, 2),
(5, 'Victoria Real', 200, 3),
(6, 'Constructor Maestro', 300, 3),
(7, 'Primera Sangre', 150, 4),
(8, 'Pentakill Épico', 1000, 4),
(9, 'Defusión Perfecta', 400, 5),
(10, 'As del Rifle', 600, 5),
(11, 'Campeón de Arena', 350, 6),
(12, 'Leyenda Apex', 800, 6),
(13, 'Ronda Perfecta', 250, 7),
(14, 'Clutch Master', 700, 7),
(15, 'Primer Gol Aéreo', 180, 8),
(16, 'Gran Campeón', 900, 8),
(17, 'Eliminación Múltiple', 320, 9),
(18, 'Tanque Imparable', 550, 9),
(19, 'Cubo Perfecto', 120, 10),
(20, 'Inmortal', 1200, 10),
(21, 'Logro 1', 4448, 2),
(22, 'Logro 2', 2704, 3),
(23, 'Logro 3', 647, 4),
(24, 'Logro 4', 695, 5),
(25, 'Logro 5', 2857, 6),
(26, 'Logro 6', 1217, 7),
(27, 'Logro 7', 2699, 8),
(28, 'Logro 8', 2977, 9),
(29, 'Logro 9', 328, 10),
(30, 'Logro 10', 3652, 11),
(31, 'Logro 11', 2466, 12),
(32, 'Logro 12', 4913, 13),
(33, 'Logro 13', 3922, 14),
(34, 'Logro 14', 834, 15),
(35, 'Logro 15', 4216, 16),
(36, 'Logro 16', 4855, 17),
(37, 'Logro 17', 1840, 18),
(38, 'Logro 18', 1423, 19),
(39, 'Logro 19', 3483, 20),
(40, 'Logro 20', 2570, 21),
(41, 'Logro 21', 1598, 22),
(42, 'Logro 22', 4205, 23),
(43, 'Logro 23', 1808, 24),
(44, 'Logro 24', 3670, 25),
(45, 'Logro 25', 2613, 26),
(46, 'Logro 26', 2505, 27),
(47, 'Logro 27', 4062, 28),
(48, 'Logro 28', 2923, 29),
(49, 'Logro 29', 1199, 30),
(50, 'Logro 30', 719, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plataforma`
--

CREATE TABLE `plataforma` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `marca` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `plataforma`
--

INSERT INTO `plataforma` (`id`, `nombre`, `marca`) VALUES
(2, 'Xbox Series X', 'Microsoft'),
(3, 'Nintendo Switch', 'Nintendo'),
(4, 'PC', 'Windows'),
(5, 'PlayStation 4', 'Sony'),
(6, 'Xbox Series S', 'Microsoft'),
(7, 'Steam Deck', 'Valve'),
(8, 'Xbox One', 'Microsoft'),
(9, 'Nintendo Switch OLED', 'Nintendo'),
(10, 'PlayStation 4 Pro', 'Sony'),
(11, 'PC', 'Microsoft Windows'),
(12, 'PlayStation 4', 'Sony'),
(13, 'PlayStation 5', 'Sony'),
(14, 'Xbox One', 'Microsoft'),
(15, 'Xbox Series X', 'Microsoft'),
(16, 'Nintendo Switch', 'Nintendo'),
(17, 'Mobile Android', 'Google'),
(18, 'Mobile iOS', 'Apple'),
(19, 'PC', 'Linux'),
(20, 'PlayStation 5', 'Gato'),
(0, 'PlayStation 5', 'Ola'),
(0, 'Xbox3', 'Sony');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion_entrenamiento`
--

CREATE TABLE `sesion_entrenamiento` (
  `id` int(11) NOT NULL,
  `fecha_agenda` datetime NOT NULL,
  `hora_ini` datetime DEFAULT NULL,
  `hora_fin` datetime DEFAULT NULL,
  `JUEGO_id` int(11) NOT NULL,
  `arbitro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `sesion_entrenamiento`
--

INSERT INTO `sesion_entrenamiento` (`id`, `fecha_agenda`, `hora_ini`, `hora_fin`, `JUEGO_id`, `arbitro`) VALUES
(1, '2025-09-27 14:00:00', '2025-09-27 14:00:00', '2025-09-27 16:00:00', 1, 3),
(2, '2025-09-27 16:30:00', '2025-09-27 16:30:00', '2025-09-27 18:30:00', 2, 15),
(3, '2025-09-28 10:00:00', '2025-09-28 10:00:00', '2025-09-28 12:00:00', 3, 23),
(4, '2025-09-28 14:00:00', '2025-09-28 14:00:00', '2025-09-28 16:30:00', 4, 31),
(5, '2025-09-29 09:00:00', '2025-09-29 09:00:00', '2025-09-29 11:00:00', 5, 40),
(6, '2025-09-29 15:00:00', '2025-09-29 15:00:00', '2025-09-29 17:00:00', 6, 50),
(7, '2025-09-30 11:00:00', '2025-09-30 11:00:00', '2025-09-30 13:30:00', 7, 3),
(8, '2025-09-30 18:00:00', '2025-09-30 18:00:00', '2025-09-30 20:00:00', 8, 15),
(9, '2025-10-01 13:00:00', '2025-10-01 13:00:00', '2025-10-01 15:30:00', 9, 23),
(10, '2025-10-01 16:00:00', '2025-10-01 16:00:00', '2025-10-01 18:00:00', 10, 31),
(11, '2025-10-02 08:30:00', '2025-10-02 08:30:00', '2025-10-02 11:00:00', 1, 40),
(12, '2025-10-02 14:30:00', '2025-10-02 14:30:00', '2025-10-02 16:30:00', 2, 50),
(13, '2025-10-03 10:30:00', '2025-10-03 10:30:00', '2025-10-03 12:30:00', 3, 3),
(14, '2025-10-03 17:00:00', '2025-10-03 17:00:00', '2025-10-03 19:30:00', 4, 15),
(15, '2025-10-04 12:00:00', '2025-10-04 12:00:00', '2025-10-04 14:00:00', 5, 23),
(16, '2025-10-04 19:00:00', '2025-10-04 19:00:00', '2025-10-04 21:00:00', 6, 31),
(17, '2025-10-05 09:30:00', '2025-10-05 09:30:00', '2025-10-05 12:00:00', 7, 40),
(18, '2025-10-05 15:30:00', '2025-10-05 15:30:00', '2025-10-05 17:30:00', 8, 50),
(19, '2025-10-06 11:30:00', '2025-10-06 11:30:00', '2025-10-06 14:00:00', 9, 3),
(20, '2025-10-06 16:30:00', '2025-10-06 16:30:00', '2025-10-06 18:30:00', 10, 15),
(21, '2025-10-01 10:00:00', '2025-10-01 10:00:00', '2025-10-01 12:00:00', 2, 2),
(22, '2025-10-02 10:00:00', '2025-10-02 10:00:00', '2025-10-02 12:00:00', 3, 3),
(23, '2025-10-03 10:00:00', '2025-10-03 10:00:00', '2025-10-03 12:00:00', 4, 4),
(24, '2025-10-04 10:00:00', '2025-10-04 10:00:00', '2025-10-04 12:00:00', 5, 5),
(25, '2025-10-05 10:00:00', '2025-10-05 10:00:00', '2025-10-05 12:00:00', 6, 6),
(26, '2025-10-06 10:00:00', '2025-10-06 10:00:00', '2025-10-06 12:00:00', 7, 7),
(27, '2025-10-07 10:00:00', '2025-10-07 10:00:00', '2025-10-07 12:00:00', 8, 8),
(28, '2025-10-08 10:00:00', '2025-10-08 10:00:00', '2025-10-08 12:00:00', 9, 9),
(29, '2025-10-09 10:00:00', '2025-10-09 10:00:00', '2025-10-09 12:00:00', 10, 10),
(30, '2025-10-10 10:00:00', '2025-10-10 10:00:00', '2025-10-10 12:00:00', 11, 11),
(31, '2025-10-11 10:00:00', '2025-10-11 10:00:00', '2025-10-11 12:00:00', 12, 12),
(32, '2025-10-12 10:00:00', '2025-10-12 10:00:00', '2025-10-12 12:00:00', 13, 13),
(33, '2025-10-13 10:00:00', '2025-10-13 10:00:00', '2025-10-13 12:00:00', 14, 14),
(34, '2025-10-14 10:00:00', '2025-10-14 10:00:00', '2025-10-14 12:00:00', 15, 15),
(35, '2025-10-15 10:00:00', '2025-10-15 10:00:00', '2025-10-15 12:00:00', 16, 16),
(36, '2025-10-16 10:00:00', '2025-10-16 10:00:00', '2025-10-16 12:00:00', 17, 17),
(37, '2025-10-17 10:00:00', '2025-10-17 10:00:00', '2025-10-17 12:00:00', 18, 18),
(38, '2025-10-18 10:00:00', '2025-10-18 10:00:00', '2025-10-18 12:00:00', 19, 19),
(39, '2025-10-19 10:00:00', '2025-10-19 10:00:00', '2025-10-19 12:00:00', 20, 20),
(40, '2025-10-20 10:00:00', '2025-10-20 10:00:00', '2025-10-20 12:00:00', 21, 21),
(41, '2025-10-21 10:00:00', '2025-10-21 10:00:00', '2025-10-21 12:00:00', 22, 22),
(42, '2025-10-22 10:00:00', '2025-10-22 10:00:00', '2025-10-22 12:00:00', 23, 23),
(43, '2025-10-23 10:00:00', '2025-10-23 10:00:00', '2025-10-23 12:00:00', 24, 24),
(44, '2025-10-24 10:00:00', '2025-10-24 10:00:00', '2025-10-24 12:00:00', 25, 25),
(45, '2025-10-25 10:00:00', '2025-10-25 10:00:00', '2025-10-25 12:00:00', 26, 26),
(46, '2025-10-26 10:00:00', '2025-10-26 10:00:00', '2025-10-26 12:00:00', 27, 27),
(47, '2025-10-27 10:00:00', '2025-10-27 10:00:00', '2025-10-27 12:00:00', 28, 28),
(48, '2025-10-28 10:00:00', '2025-10-28 10:00:00', '2025-10-28 12:00:00', 29, 29),
(49, '2025-10-29 10:00:00', '2025-10-29 10:00:00', '2025-10-29 12:00:00', 30, 30),
(50, '2025-10-30 10:00:00', '2025-10-30 10:00:00', '2025-10-30 12:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefono`
--

CREATE TABLE `telefono` (
  `id` int(11) NOT NULL,
  `numero` varchar(45) NOT NULL,
  `tipo` varchar(45) NOT NULL,
  `USUARIO_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `telefono`
--

INSERT INTO `telefono` (`id`, `numero`, `tipo`, `USUARIO_id`) VALUES
(1, '3012345678', 'celular', 1),
(2, '3109876543', 'celular', 2),
(3, '6017654321', 'fijo', 3),
(4, '3156789012', 'celular', 4),
(5, '3023456789', 'celular', 5),
(6, '6018901234', 'fijo', 6),
(7, '3134567890', 'celular', 7),
(8, '3187654321', 'celular', 8),
(9, '3045678901', 'celular', 9),
(10, '6019012345', 'fijo', 10),
(11, '3176543210', 'celular', 11),
(12, '3198765432', 'celular', 12),
(13, '3056789013', 'celular', 13),
(14, '6010123456', 'fijo', 14),
(15, '3112345679', 'celular', 15),
(16, '3189876544', 'celular', 16),
(17, '3067890124', 'celular', 17),
(18, '3201234567', 'celular', 18),
(19, '6011234567', 'fijo', 19),
(20, '3143456780', 'celular', 20),
(21, '3157890123', 'celular', 21),
(22, '3082345678', 'celular', 22),
(23, '6012345678', 'fijo', 23),
(24, '3196789012', 'celular', 24),
(25, '3128901234', 'celular', 25),
(26, '3073456789', 'celular', 26),
(27, '6013456789', 'fijo', 27),
(28, '3184567890', 'celular', 28),
(29, '3159012345', 'celular', 29),
(30, '3096543210', 'celular', 30),
(31, '3005953412', 'celular', 1),
(32, '3001000001', 'Movil', 1),
(33, '3001000002', 'Movil', 2),
(34, '3001000003', 'Movil', 3),
(35, '3001000004', 'Movil', 4),
(36, '3001000005', 'Movil', 5),
(37, '3001000006', 'Movil', 6),
(38, '3001000007', 'Movil', 7),
(39, '3001000008', 'Movil', 8),
(40, '3001000009', 'Movil', 9),
(41, '3001000010', 'Movil', 10),
(42, '3001000011', 'Movil', 11),
(43, '3001000012', 'Movil', 12),
(44, '3001000013', 'Movil', 13),
(45, '3001000014', 'Movil', 14),
(46, '3001000015', 'Movil', 15),
(47, '3001000016', 'Movil', 16),
(48, '3001000017', 'Movil', 17),
(49, '3001000018', 'Movil', 18),
(50, '3001000019', 'Movil', 19),
(51, '3001000020', 'Movil', 20),
(52, '3001000021', 'Movil', 21),
(53, '3001000022', 'Movil', 22),
(54, '3001000023', 'Movil', 23),
(55, '3001000024', 'Movil', 24),
(56, '3001000025', 'Movil', 25),
(57, '3001000026', 'Movil', 26),
(58, '3001000027', 'Movil', 27),
(59, '3001000028', 'Movil', 28),
(60, '3001000029', 'Movil', 29),
(61, '3001000030', 'Movil', 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id`, `nombre`, `descripcion`) VALUES
(1, 'administrador', 'Gestiona el sistema y usuarios'),
(2, 'jugador', 'Participa en entrenamientos y torneos'),
(3, 'arbitro', 'Supervisa sesiones y competencias'),
(4, 'acudiente', 'Responsable legal de jugadores menores'),
(5, 'entrenador', 'Dirige entrenamientos y equipos'),
(6, 'soporte tecnico', 'Mantiene equipos y infraestructura'),
(7, 'Jugador', 'Participante de torneos'),
(8, 'Arbitro', 'Juez de partidas'),
(9, 'Admin', 'Administrador del sistema'),
(10, 'Espectador', 'Usuario visualizador'),
(11, 'Entrenador', 'Entrenador de equipos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `tipo_documento` varchar(45) NOT NULL,
  `numero_documento` varchar(45) NOT NULL,
  `primer_nombre` varchar(45) NOT NULL,
  `segundo_nombre` varchar(45) DEFAULT NULL,
  `primer_apellido` varchar(45) NOT NULL,
  `segundo_apellido` varchar(45) DEFAULT NULL,
  `fecha_nacimiento` datetime NOT NULL,
  `sexo` varchar(45) DEFAULT NULL,
  `direccion_domicilio` varchar(45) NOT NULL,
  `nickname` varchar(45) DEFAULT NULL,
  `clave` varchar(45) DEFAULT NULL,
  `acudiente` int(11) DEFAULT NULL,
  `COMUNA_BARRIO_id` int(11) NOT NULL,
  `TIPO_USUARIO_id` int(11) NOT NULL,
  `EQUIPO_JUEGO_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `tipo_documento`, `numero_documento`, `primer_nombre`, `segundo_nombre`, `primer_apellido`, `segundo_apellido`, `fecha_nacimiento`, `sexo`, `direccion_domicilio`, `nickname`, `clave`, `acudiente`, `COMUNA_BARRIO_id`, `TIPO_USUARIO_id`, `EQUIPO_JUEGO_id`) VALUES
(1, 'CC', '1032456789', 'Carlos', 'Andrés', 'Rodríguez', 'López', '1990-03-15 00:00:00', 'M', 'Cra 7 # 45-23', 'CarlosGamer', 'pass123', NULL, 1, 1, 1),
(2, 'TI', '1098765432', 'María', 'Elena', 'García', 'Hernández', '2005-07-22 00:00:00', 'F', 'Calle 25 # 12-45', 'MariGamer', 'maria456', 1, 2, 2, 1),
(3, 'CC', '1076543210', 'Alejandro', NULL, 'Martínez', 'Gómez', '1988-11-08 00:00:00', 'M', 'Av 68 # 123-56', 'AlejRef', 'referee1', NULL, 3, 3, 2),
(4, 'CC', '1054321098', 'Ana', 'Sofía', 'Pérez', 'Ruiz', '1975-09-12 00:00:00', 'F', 'Cra 15 # 78-90', NULL, 'ana789', NULL, 4, 4, 3),
(5, 'CC', '1087654321', 'Diego', 'Fernando', 'López', 'Castro', '1985-04-18 00:00:00', 'M', 'Calle 134 # 45-67', 'CoachDiego', 'coach123', NULL, 5, 5, 1),
(6, 'CC', '1098765123', 'Jorge', NULL, 'Morales', 'Díaz', '1992-01-25 00:00:00', 'M', 'Cra 30 # 56-12', 'TechJorge', 'tech456', NULL, 6, 6, 2),
(7, 'TI', '1023456789', 'Valentina', 'Isabel', 'Torres', 'Vargas', '2006-12-03 00:00:00', 'F', 'Calle 45 # 23-89', 'ValePixel', 'vale789', 4, 7, 2, 3),
(8, 'CC', '1067890123', 'Luis', 'Miguel', 'Ramírez', 'Jiménez', '1989-06-14 00:00:00', 'M', 'Av 19 # 67-45', 'LuisShad', 'luis123', NULL, 8, 2, 4),
(9, 'TI', '1045678901', 'Camila', NULL, 'Herrera', 'Moreno', '2007-02-28 00:00:00', 'F', 'Cra 12 # 34-78', 'CamiFire', 'cami456', 4, 9, 2, 5),
(10, 'CC', '1056789012', 'Ricardo', 'Javier', 'González', 'Salazar', '1987-08-09 00:00:00', 'M', 'Calle 67 # 89-23', 'RicardoIce', 'rick789', NULL, 10, 2, 6),
(11, 'TI', '1034567890', 'Isabella', 'María', 'Castillo', 'Rivera', '2005-05-17 00:00:00', 'F', 'Av 45 # 12-34', 'IsaStorm', 'isa123', 4, 11, 2, 7),
(12, 'CC', '1078901234', 'Sebastián', NULL, 'Vásquez', 'Cruz', '1990-10-21 00:00:00', 'M', 'Cra 56 # 78-90', 'SebaGold', 'seba456', NULL, 12, 2, 8),
(13, 'TI', '1012345678', 'Sofía', 'Andrea', 'Mendoza', 'Ortiz', '2006-03-05 00:00:00', 'F', 'Calle 89 # 45-67', 'SofiNight', 'sofi789', 4, 13, 2, 9),
(14, 'CC', '1089012345', 'Andrés', 'Felipe', 'Rojas', 'Mejía', '1991-12-30 00:00:00', 'M', 'Av 23 # 56-12', 'AndresSteel', 'andres123', NULL, 14, 2, 10),
(15, 'CC', '1045612378', 'Patricia', NULL, 'Silva', 'Aguilar', '1986-07-16 00:00:00', 'F', 'Cra 78 # 34-90', 'PatCyber', 'pat456', NULL, 15, 3, 11),
(16, 'TI', '1067823451', 'Mateo', 'Santiago', 'Córdoba', 'Parra', '2007-01-11 00:00:00', 'M', 'Calle 12 # 67-89', 'MateoRed', 'mateo789', 15, 16, 2, 12),
(17, 'CC', '1078234567', 'Carmen', 'Lucía', 'Delgado', 'Rueda', '1983-04-07 00:00:00', 'F', 'Av 90 # 23-45', NULL, 'carmen123', NULL, 17, 4, 13),
(18, 'TI', '1023456781', 'Nicolás', NULL, 'Poveda', 'Téllez', '2005-09-19 00:00:00', 'M', 'Cra 45 # 78-12', 'NicoBlue', 'nico456', 17, 18, 2, 13),
(19, 'CC', '1056781234', 'Fernando', 'Alberto', 'Chávez', 'Monsalve', '1988-02-13 00:00:00', 'M', 'Calle 56 # 90-34', 'FerCoach', 'fer789', NULL, 19, 5, 14),
(20, 'TI', '1034567812', 'Daniela', 'Alejandra', 'Buitrago', 'Forero', '2006-11-26 00:00:00', 'F', 'Av 34 # 12-78', 'DaniGreen', 'dani123', 17, 20, 2, 14),
(21, 'CC', '1067812345', 'Roberto', NULL, 'Quintero', 'Espinosa', '1992-08-04 00:00:00', 'M', 'Cra 23 # 45-67', 'RobertoTech', 'rob456', NULL, 1, 6, 15),
(22, 'TI', '1078123456', 'Gabriela', 'Fernanda', 'Carrillo', 'Bedoya', '2007-06-18 00:00:00', 'F', 'Calle 78 # 56-90', 'GabiWhite', 'gabi789', 21, 2, 2, 15),
(23, 'CC', '1045678123', 'Mauricio', 'Enrique', 'Sánchez', 'Trujillo', '1989-03-29 00:00:00', 'M', 'Av 12 # 34-56', 'MauricioArb', 'mauri123', NULL, 3, 3, 16),
(24, 'TI', '1056712345', 'Valeria', NULL, 'Ospina', 'León', '2005-12-01 00:00:00', 'F', 'Cra 67 # 89-12', 'ValeBlack', 'vale456', 21, 4, 2, 16),
(25, 'CC', '1067123456', 'Esteban', 'Camilo', 'Restrepo', 'Arango', '1986-05-22 00:00:00', 'M', 'Calle 90 # 23-78', 'EstebanAdmin', 'este789', NULL, 5, 1, 17),
(26, 'TI', '1078456123', 'Mariana', 'Valentina', 'Cardona', 'Giraldo', '2006-10-15 00:00:00', 'F', 'Av 56 # 78-34', 'MariSilver', 'mari123', 25, 6, 2, 17),
(27, 'CC', '1034512678', 'Julián', NULL, 'Zapata', 'Vélez', '1991-07-08 00:00:00', 'M', 'Cra 89 # 12-45', 'JulianCoach', 'juli456', NULL, 7, 5, 18),
(28, 'TI', '1045623781', 'Carolina', 'Sofía', 'Muñoz', 'Henao', '2007-04-03 00:00:00', 'F', 'Calle 23 # 67-90', 'CaroPurple', 'caro789', 27, 8, 2, 18),
(29, 'CC', '1056734812', 'Gabriel', 'Antonio', 'Jaramillo', 'Duque', '1988-01-17 00:00:00', 'M', 'Av 78 # 45-12', 'GabrielTech', 'gab123', NULL, 9, 6, 19),
(30, 'TI', '1067845123', 'Alexa', NULL, 'Franco', 'Montoya', '2005-08-24 00:00:00', 'F', 'Cra 12 # 56-89', 'AlexaOrange', 'alexa456', 29, 10, 2, 19),
(31, 'CC', '1078956234', 'Iván', 'Stiven', 'Bermúdez', 'Ramos', '1990-11-12 00:00:00', 'M', 'Calle 45 # 78-23', 'IvanRef', 'ivan789', NULL, 11, 3, 20),
(32, 'TI', '1023467891', 'Melissa', 'Andrea', 'Acosta', 'Villamil', '2006-02-06 00:00:00', 'F', 'Av 67 # 90-45', 'MelPink', 'mel123', 31, 12, 2, 20),
(33, 'CC', '1034578912', 'Oscar', NULL, 'Patiño', 'Alzate', '1987-09-28 00:00:00', 'M', 'Cra 90 # 23-67', 'OscarAdmin', 'oscar456', NULL, 13, 1, 1),
(34, 'CC', '1045689023', 'Laura', 'Cristina', 'Navarro', 'Hurtado', '1984-06-11 00:00:00', 'F', 'Calle 34 # 56-12', NULL, 'laura789', NULL, 14, 4, 2),
(35, 'TI', '1056790134', 'Kevin', 'Alejandro', 'Escobar', 'Cadavid', '2007-03-20 00:00:00', 'M', 'Av 89 # 12-78', 'KevinDragon', 'kev123', 34, 15, 2, 1),
(36, 'CC', '1067801245', 'Paola', NULL, 'Ríos', 'Castaño', '1989-12-07 00:00:00', 'F', 'Cra 23 # 78-45', 'PaolaCoach', 'pao456', NULL, 16, 5, 2),
(37, 'TI', '1078912356', 'Santiago', 'David', 'Londoño', 'Urrea', '2005-05-14 00:00:00', 'M', 'Calle 67 # 34-90', 'SantiThunder', 'santi789', 36, 17, 2, 2),
(38, 'CC', '1023478945', 'Mónica', 'Patricia', 'Villa', 'Osorio', '1986-10-25 00:00:00', 'F', 'Av 45 # 67-23', 'MonicaTech', 'moni123', NULL, 18, 6, 3),
(39, 'TI', '1034589067', 'Tomás', NULL, 'Grajales', 'Correa', '2006-07-02 00:00:00', 'M', 'Cra 78 # 90-56', 'TomasPixel', 'tomas456', 38, 19, 2, 3),
(40, 'CC', '1045690178', 'Diana', 'Marcela', 'Betancur', 'Arbeláez', '1988-04-19 00:00:00', 'F', 'Calle 12 # 45-89', 'DianaRef', 'diana789', NULL, 20, 3, 4),
(41, 'TI', '1056701289', 'Brayan', 'Stiven', 'Carvajal', 'Tamayo', '2007-01-08 00:00:00', 'M', 'Av 56 # 23-67', 'BrayanShadow', 'brayan123', 40, 1, 2, 4),
(42, 'CC', '1067812390', 'Claudia', NULL, 'Posada', 'Marín', '1983-08-16 00:00:00', 'F', 'Cra 34 # 78-12', NULL, 'clau456', NULL, 2, 4, 5),
(43, 'TI', '1078923401', 'Felipe', 'Andrés', 'Giraldo', 'Palacio', '2005-11-23 00:00:00', 'M', 'Calle 89 # 56-34', 'FelipeFire2', 'felipe789', 42, 3, 2, 5),
(44, 'CC', '1023456792', 'Andrea', 'Juliana', 'Tabares', 'Rendón', '1991-02-14 00:00:00', 'F', 'Av 23 # 67-90', 'AndreaAdmin', 'andre123', NULL, 4, 1, 6),
(45, 'TI', '1034567823', 'Dylan', NULL, 'Botero', 'Quintana', '2006-09-05 00:00:00', 'M', 'Cra 67 # 12-78', 'DylanIce2', 'dylan456', 44, 5, 2, 6),
(46, 'CC', '1045678934', 'Esperanza', 'María', 'Castrillón', 'Ocampo', '1987-06-30 00:00:00', 'F', 'Calle 78 # 45-23', 'EspeCoach', 'espe789', NULL, 6, 5, 7),
(47, 'TI', '1056789045', 'Jhon', 'Sebastián', 'Monsalve', 'García', '2007-12-18 00:00:00', 'M', 'Av 12 # 89-56', 'JhonStorm2', 'jhon123', 46, 7, 2, 7),
(48, 'CC', '1067890156', 'Rocío', NULL, 'Piedrahita', 'López', '1985-03-27 00:00:00', 'F', 'Cra 45 # 23-67', 'RocioTech', 'rocio456', NULL, 8, 6, 8),
(49, 'TI', '1078901267', 'Matías', 'Alejandro', 'Holguín', 'Ruiz', '2005-10-10 00:00:00', 'M', 'Calle 56 # 78-34', 'MatiasGold2', 'mati789', 48, 9, 2, 8),
(50, 'CC', '1089012378', 'Gloria', 'Elena', 'Atehortúa', 'Pérez', '1982-07-21 00:00:00', 'F', 'Av 89 # 34-12', 'GloriaRef', 'gloria123', NULL, 10, 3, 9),
(51, 'CC', '1000001', 'Pedro', NULL, 'Ramirez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 1 # 1-1', 'User1', 'pass1', NULL, 2, 2, 2),
(52, 'CC', '1000002', 'Pedro', NULL, 'Castro', NULL, '2000-01-01 00:00:00', NULL, 'Calle 2 # 2-2', 'User2', 'pass2', NULL, 3, 3, 3),
(53, 'CC', '1000003', 'Felipe', NULL, 'Castro', NULL, '2000-01-01 00:00:00', NULL, 'Calle 3 # 3-3', 'User3', 'pass3', NULL, 4, 4, 4),
(54, 'CC', '1000004', 'Daniel', NULL, 'Rodriguez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 4 # 4-4', 'User4', 'pass4', NULL, 5, 5, 5),
(55, 'CC', '1000005', 'Jose', NULL, 'Castro', NULL, '2000-01-01 00:00:00', NULL, 'Calle 5 # 5-5', 'User5', 'pass5', NULL, 6, 1, 6),
(56, 'CC', '1000006', 'Laura', NULL, 'Ruiz', NULL, '2000-01-01 00:00:00', NULL, 'Calle 6 # 6-6', 'User6', 'pass6', NULL, 7, 2, 7),
(57, 'CC', '1000007', 'David', NULL, 'Garcia', NULL, '2000-01-01 00:00:00', NULL, 'Calle 7 # 7-7', 'User7', 'pass7', NULL, 8, 3, 8),
(58, 'CC', '1000008', 'Camila', NULL, 'Flores', NULL, '2000-01-01 00:00:00', NULL, 'Calle 8 # 8-8', 'User8', 'pass8', NULL, 9, 4, 9),
(59, 'CC', '1000009', 'Andres', NULL, 'Rivera', NULL, '2000-01-01 00:00:00', NULL, 'Calle 9 # 9-9', 'User9', 'pass9', NULL, 10, 5, 10),
(60, 'CC', '1000010', 'Gabriel', NULL, 'Gonzalez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 10 # 10-10', 'User10', 'pass10', NULL, 11, 1, 11),
(61, 'CC', '1000011', 'Camila', NULL, 'Martinez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 11 # 11-11', 'User11', 'pass11', NULL, 12, 2, 12),
(62, 'CC', '1000012', 'Alejandro', NULL, 'Alvarez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 12 # 12-12', 'User12', 'pass12', NULL, 13, 3, 13),
(63, 'CC', '1000013', 'Diego', NULL, 'Hernandez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 13 # 13-13', 'User13', 'pass13', NULL, 14, 4, 14),
(64, 'CC', '1000014', 'Ana', NULL, 'Hernandez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 14 # 14-14', 'User14', 'pass14', NULL, 15, 5, 15),
(65, 'CC', '1000015', 'David', NULL, 'Ruiz', NULL, '2000-01-01 00:00:00', NULL, 'Calle 15 # 15-15', 'User15', 'pass15', NULL, 16, 1, 16),
(66, 'CC', '1000016', 'Ana', NULL, 'Lopez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 16 # 16-16', 'User16', 'pass16', NULL, 17, 2, 17),
(67, 'CC', '1000017', 'Juan', NULL, 'Castro', NULL, '2000-01-01 00:00:00', NULL, 'Calle 17 # 17-17', 'User17', 'pass17', NULL, 18, 3, 18),
(68, 'CC', '1000018', 'Juan', NULL, 'Rivera', NULL, '2000-01-01 00:00:00', NULL, 'Calle 18 # 18-18', 'User18', 'pass18', NULL, 19, 4, 19),
(69, 'CC', '1000019', 'Felipe', NULL, 'Lopez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 19 # 19-19', 'User19', 'pass19', NULL, 20, 5, 20),
(70, 'CC', '1000020', 'Sofia', NULL, 'Lopez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 20 # 20-20', 'User20', 'pass20', NULL, 21, 1, 21),
(71, 'CC', '1000021', 'Valentina', NULL, 'Rivera', NULL, '2000-01-01 00:00:00', NULL, 'Calle 21 # 21-21', 'User21', 'pass21', NULL, 22, 2, 22),
(72, 'CC', '1000022', 'Juan', NULL, 'Moreno', NULL, '2000-01-01 00:00:00', NULL, 'Calle 22 # 22-22', 'User22', 'pass22', NULL, 23, 3, 23),
(73, 'CC', '1000023', 'Pedro', NULL, 'Lopez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 23 # 23-23', 'User23', 'pass23', NULL, 24, 4, 24),
(74, 'CC', '1000024', 'Andres', NULL, 'Torres', NULL, '2000-01-01 00:00:00', NULL, 'Calle 24 # 24-24', 'User24', 'pass24', NULL, 25, 5, 25),
(75, 'CC', '1000025', 'Felipe', NULL, 'Rivera', NULL, '2000-01-01 00:00:00', NULL, 'Calle 25 # 25-25', 'User25', 'pass25', NULL, 26, 1, 26),
(76, 'CC', '1000026', 'Jose', NULL, 'Diaz', NULL, '2000-01-01 00:00:00', NULL, 'Calle 26 # 26-26', 'User26', 'pass26', NULL, 27, 2, 27),
(77, 'CC', '1000027', 'Camila', NULL, 'Lopez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 27 # 27-27', 'User27', 'pass27', NULL, 28, 3, 28),
(78, 'CC', '1000028', 'Ana', NULL, 'Ramirez', NULL, '2000-01-01 00:00:00', NULL, 'Calle 28 # 28-28', 'User28', 'pass28', NULL, 29, 4, 29),
(79, 'CC', '1000029', 'Ana', NULL, 'Torres', NULL, '2000-01-01 00:00:00', NULL, 'Calle 29 # 29-29', 'User29', 'pass29', NULL, 30, 5, 30),
(80, 'CC', '1000030', 'Jose', NULL, 'Garcia', NULL, '2000-01-01 00:00:00', NULL, 'Calle 30 # 30-30', 'User30', 'pass30', NULL, 31, 1, 1),
(0, '', '', 'carolina', NULL, 'Lopez', NULL, '1995-12-20 00:00:00', NULL, '', NULL, NULL, NULL, 0, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
