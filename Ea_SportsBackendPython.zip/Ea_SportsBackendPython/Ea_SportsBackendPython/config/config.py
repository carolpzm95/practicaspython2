class Config:
    MYSQL_HOST = 'localhost'        # Servidor de MySQL
    MYSQL_USER = 'Carolina'         # usuario de MySQL
    MYSQL_PASSWORD = 'Dulcemaria30'  # contraseña de MySQL
    MYSQL_DB = 'inder_e_sports'     # Nombre base de datos
    MYSQL_PORT = 3306

    DEBUG = True
    PORT = 3000