import pymysql
import pymysql.cursors

from flask import current_app as app

def get_db_connection():
    """Establece y retorna una conexión a la base de datos MySQL"""
    try:
        conn = pymysql.connect(
            host=app.config["MYSQL_HOST"],
            user=app.config["MYSQL_USER"],
            password=app.config["MYSQL_PASSWORD"],
            db=app.config["MYSQL_DB"],
            cursorclass=pymysql.cursors.DictCursor
        )
        return conn
    except pymysql.Error as e:
        print(f"Error conectando a la base de datos: {e}")
        return None