from models.db import get_db_connection

def handle_db_operation(query, data=None, fetch_mode='all'):
    """Función central para ejecutar cualquier operación SQL."""
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "No se pudo establecer conexión con la base de datos."
            
        cur = conn.cursor()
        cur.execute(query, data)
        
        #  aqui estan las operaciones de escritura inser, update y delete
        if query.strip().upper().startswith(('INSERT', 'UPDATE', 'DELETE')):
            conn.commit()
            cur.close()
            conn.close()
            return True, None
        
        #  aqui estan las operaciones de lectura select
        result = cur.fetchone() if fetch_mode == 'one' else cur.fetchall()
        cur.close()
        conn.close()
        return True, result
        
    except Exception as e:
        error_msg = str(e)
        if "foreign key" in error_msg.lower() or "integrity" in error_msg.lower():
            return False, "Error de integridad: ID foráneo no existe o está en uso."
        print(f"Error en la operación de DB: {e}")
        return False, error_msg