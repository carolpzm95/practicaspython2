from flask import Flask
from flask_cors import CORS
from config import Config

# 1. INICIO DE LA APLICACIÓN Y CARGA DE CONFIGURACIÓN
app = Flask(__name__)
app.config.from_object(Config)

#  aqui esta la Configuración de CORS
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)

app.url_map.strict_slashes = False  # Evita redirecciones de slash

# 2. SE IMPORTAN BLUEPRINTS (Después de crear app)
from routes.usuario_routes import usuario_bp
from routes.plataforma_routes import plataforma_bp
from routes.juego_routes import juego_bp
from routes.equipo_routes import equipo_bp

# 3. REGISTRAR RUTAS
app.register_blueprint(plataforma_bp, url_prefix='/api/plataformas')
app.register_blueprint(juego_bp, url_prefix='/api/juegos')
app.register_blueprint(equipo_bp, url_prefix='/api/equipos')
app.register_blueprint(usuario_bp, url_prefix='/api/usuarios')

@app.route('/')
def home():
    return {"message": "¡Backend funcionando correctamente!", "status": "ok"}

if __name__ == '__main__':
    app.run(debug=True, port=3000)
