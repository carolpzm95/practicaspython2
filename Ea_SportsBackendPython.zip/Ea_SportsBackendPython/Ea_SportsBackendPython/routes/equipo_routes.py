from flask import Blueprint, request, jsonify
from models.db import get_db_connection 

equipo_bp = Blueprint('equipo', __name__)

@equipo_bp.route('/', methods=['GET', 'POST'])
def handle_equipos():
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    # RUTA GET
    if request.method == 'GET':
        
        query = "SELECT id, nombre, nivel, horas, JUEGO_id AS JUEGO_id FROM equipo_juego"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                # aca se utilizó  DictCursor devuelve diccionarios listos
                equipos = cursor.fetchall()
                
                return jsonify(equipos)
                
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

    # RUTA POST
    if request.method == 'POST':
        data = request.get_json()
        nombre = data.get('nombre')
        nivel = data.get('nivel')
        # aca se Añadio valor predeterminado seguro en caso de que falte
        horas = data.get('horas', 0) 
        # aca se lee  el campo que el frontend envía 
        JUEGO_id = data.get('JUEGO_id') 
        
        # aca se valida
        if not nombre or nivel is None or JUEGO_id is None: 
            return jsonify({'error': 'Faltan campos obligatorios (nombre, nivel, JUEGO_id)'}), 400

        # aca estan los inserts
        query = "INSERT INTO equipo_juego (nombre, nivel, horas, JUEGO_id) VALUES (%s, %s, %s, %s)"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (nombre, nivel, horas, JUEGO_id))
                conn.commit()
                return jsonify({'message': 'Equipo creado', 'id': cursor.lastrowid}), 201
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

@equipo_bp.route('/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def handle_equipo(id):
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    try:
        # ESTA ES LA RUTA GET
        if request.method == 'GET':
            
            query = "SELECT id, nombre, nivel, horas, JUEGO_id AS JUEGO_id FROM equipo_juego WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                # se utilizo fetchone() el cual,devuelve el diccionario listo.
                equipo = cursor.fetchone()
                
                if equipo:
                    return jsonify(equipo) # Devuelve el diccionario formateado
                
                return jsonify({'error': 'Equipo no encontrado'}), 404
        
        # ESTA ES LA RUTA PUT 
        if request.method == 'PUT':
            data = request.get_json()
            nombre = data.get('nombre')
            nivel = data.get('nivel')
            horas = data.get('horas')
        
            JUEGO_id = data.get('JUEGO_id') 
            
            if not nombre or nivel is None or horas is None or JUEGO_id is None: 
                return jsonify({'error': 'Faltan campos obligatorios'}), 400

            
            query = "UPDATE equipo_juego SET nombre = %s, nivel = %s, horas = %s, JUEGO_id = %s WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (nombre, nivel, horas, JUEGO_id, id))
                conn.commit()
                if cursor.rowcount == 0: 
                    return jsonify({'error': 'Equipo no encontrado o sin cambios'}), 404
                return jsonify({'message': 'Equipo actualizado'})
        
        #  ESTA ES LA RUTA DELETE
        if request.method == 'DELETE':
            query = "DELETE FROM equipo_juego WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                conn.commit()
                if cursor.rowcount == 0: 
                    return jsonify({'error': 'Equipo no encontrado'}), 404
                return jsonify({'message': 'Equipo eliminado'})

    except Exception as e:
        if conn: 
            conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        if conn: 
            conn.close()