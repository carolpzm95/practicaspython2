from flask import Blueprint, request, jsonify
from models.db import get_db_connection 

usuario_bp = Blueprint('usuario', __name__)
#aqui estan los metodos get y post
@usuario_bp.route('/', methods=['GET', 'POST'])
def handle_usuarios():
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    if request.method == 'GET':
        query = "SELECT id, nombre, email, nickname, fecha_registro FROM USUARIO"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                usuarios = cursor.fetchall()
                return jsonify(usuarios)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()
    
    elif request.method == 'POST':
        data = request.get_json()
        
        if not data or 'nombre' not in data or 'email' not in data:
            return jsonify({'error': 'Nombre y email son requeridos'}), 400
        
        query = """
            INSERT INTO USUARIO (nombre, email, nickname, fecha_registro) 
            VALUES (%s, %s, %s, NOW())
        """
        
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (
                    data.get('nombre'),
                    data.get('email'),
                    data.get('nickname')
                ))
                conn.commit()
                
                return jsonify({
                    'message': 'Usuario creado exitosamente',
                    'id': cursor.lastrowid
                }), 201
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

# metodos get post y delete
@usuario_bp.route('/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def handle_usuario(id):
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    try:
        if request.method == 'GET':
            query = "SELECT id, nombre, email, nickname, fecha_registro FROM USUARIO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                usuario = cursor.fetchone()
                
                if usuario:
                    return jsonify(usuario)
                
                return jsonify({'error': 'Usuario no encontrado'}), 404
        
        elif request.method == 'PUT':
            data = request.get_json()
            
            if not data or 'nombre' not in data or 'email' not in data:
                return jsonify({'error': 'Nombre y email son requeridos'}), 400
            
            query = """
                UPDATE USUARIO 
                SET nombre = %s, email = %s, nickname = %s 
                WHERE id = %s
            """
            
            with conn.cursor() as cursor:
                cursor.execute(query, (
                    data.get('nombre'),
                    data.get('email'),
                    data.get('nickname'),
                    id
                ))
                conn.commit()
                
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Usuario no encontrado'}), 404
                
                return jsonify({'message': 'Usuario actualizado exitosamente'})
        
        elif request.method == 'DELETE':
            query = "DELETE FROM USUARIO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                conn.commit()
                
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Usuario no encontrado'}), 404
                
                return jsonify({'message': 'Usuario eliminado exitosamente'})
    
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()