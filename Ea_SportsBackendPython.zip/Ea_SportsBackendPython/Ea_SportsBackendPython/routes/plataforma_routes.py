from flask import Blueprint, request, jsonify
from models.db import get_db_connection

plataforma_bp = Blueprint('plataforma', __name__)

# AQUI SE UTILIZA EL GET Y POST POR ID
@plataforma_bp.route('/', methods=['GET', 'POST'])
def handle_plataformas():
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Fallo en la conexión'}), 500

    # METODO GET
    if request.method == 'GET':
        print('ingreso al get')
        query = "SELECT id, nombre, marca FROM PLATAFORMA"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                plataformas = cursor.fetchall()
                return jsonify(plataformas)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

    # METODO POST
    elif request.method == 'POST':
        data = request.get_json()
        if not data or 'nombre' not in data or 'marca' not in data:
            return jsonify({'error': 'Nombre y marca son requeridos'}), 400

        query = "INSERT INTO PLATAFORMA (nombre, marca) VALUES (%s, %s)"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (data['nombre'], data['marca']))
                conn.commit()
                return jsonify({
                    'message': 'Plataforma creada exitosamente',
                    'id': cursor.lastrowid
                }), 201
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()


# metodo put y delete con id
@plataforma_bp.route('/<int:id>', methods=['PUT', 'DELETE'])
def handle_plataforma_by_id(id):
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Fallo en la conexión'}), 500

    # aqui esta el metodo put
    if request.method == 'PUT':
        print('metodo put')
        data = request.get_json()
        if not data or 'nombre' not in data or 'marca' not in data:
            return jsonify({'error': 'Nombre y marca son requeridos'}), 400

        query = "UPDATE PLATAFORMA SET nombre = %s, marca = %s WHERE id = %s"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (data['nombre'], data['marca'], id))
                conn.commit()
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Plataforma no encontrada'}), 404
                return jsonify({'message': 'Plataforma actualizada exitosamente'})
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

    # aqui esta el metodo delete
    elif request.method == 'DELETE':
        query = "DELETE FROM PLATAFORMA WHERE id = %s"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                conn.commit()
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Plataforma no encontrada'}), 404
                return jsonify({'message': 'Plataforma eliminada exitosamente'})
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()
