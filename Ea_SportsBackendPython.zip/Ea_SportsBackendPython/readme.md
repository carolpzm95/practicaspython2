Aplicación de Gestión de Juegos

Esta aplicación permite gestionar Plataformas, Juegos y Equipos a través de un frontend web y un backend en Flask con API REST. Es ideal para organizar información de videojuegos y equipos de jugadores.

Funcionalidades
Plataformas

Listar todas las plataformas.

Crear nuevas plataformas.

Editar plataformas existentes.

Eliminar plataformas.

Juegos

Listar todos los juegos.

Crear nuevos juegos (vinculados a una plataforma).

Editar juegos existentes.

Eliminar juegos.

Equipos

Listar todos los equipos.

Crear nuevos equipos (vinculados a un juego).

Editar equipos existentes.

Eliminar equipos.

Tecnologías
Backend

Python 3

Flask: Framework web.

Flask-CORS: Para habilitar solicitudes desde el frontend.

SQLAlchemy 

Frontend

HTML / CSS / JavaScript

Modales para crear y editar registros.

Fetch API para consumir la API REST del backend.

Instalación
Backend

Clonar el repositorio

Crear y activar un entorno virtual:

python -m venv venv
source venv/bin/activate   # Linux / Mac
venv\Scripts\activate      # Windows


Instalar dependencias:

pip install -r requirements.txt


Configurar config.py según tus necesidades (puerto, base de datos, etc.)

Ejecutar el backend:

python app.py


El backend correrá por defecto en http://localhost:5000.

Frontend

Abrir el archivo index.html en un navegador.

Asegurarse de que la variable API_BASE_URL apunte al backend:

const API_BASE_URL = 'http://localhost:5000/api';


Navegar entre las secciones de Plataformas, Juegos y Equipos.

Usar los botones Crear / Editar / Eliminar para administrar los registros.

Uso

Listar registros: La tabla de cada sección muestra todos los registros disponibles.

Crear registro: Abrir el modal y llenar el formulario.

Editar registro: Hacer clic en “Editar” y modificar los datos en el modal.

Eliminar registro: Hacer clic en “Eliminar” y confirmar.

Notas

Asegúrate de que el backend esté corriendo antes de usar el frontend.

El PUT y DELETE requieren que el backend permita CORS con métodos PUT y DELETE.

Postman puede funcionar incluso si CORS no está configurado; el navegador requiere configuración correcta de CORS para editar registros.

Estructura del proyecto
EA_SPORTSBACKENDPYTHON/
├── .venv/                         # Entorno Virtual 1 (Ignorado por Git)
├── venv/                          # Entorno Virtual 2 (Igual que .venv)
├── .gitignore                     # Archivo de configuración de Git
├── app.py                         # Punto de entrada de la aplicación
├── config/                        # Configuración
│   ├── __init__.py                # Marca config como paquete
│   └── config.py                  # Variables de entorno y ajustes
├── models/                        # Modelos de Datos (Entidades)
│   ├── __init__.py                # Marca models como paquete
│   └── db.py                      # Conexión/Configuración de la Base de Datos
├── routes/                        # Rutas / Endpoints de la API
│   ├── __init__.py                # Marca routes como paquete
│   ├── equipo_routes.py           # Rutas para la gestión de equipos
│   ├── juego_routes.py            # Rutas para la gestión de juegos
│   ├── plataforma_routes.py       # Rutas para la gestión de plataformas
│   └── usuario_routes.py          # Rutas para la gestión de usuarios
└── services/                      # Lógica de Negocio
    ├── __init__.py                # Marca services como paquete
    └── data_service.py            # Funciones de lógica de negocio o manipulación de datos

Autores

Black and white
