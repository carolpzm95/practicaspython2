from flask import Blueprint, request, jsonify
from models.db import get_db_connection 

equipo_bp = Blueprint('equipo', __name__)

@equipo_bp.route('/', methods=['GET', 'POST'])
def handle_equipos():
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    # --- RUTA GET (Listar) ---
    if request.method == 'GET':
        # CORRECCIÓN CLAVE: Usamos AS JUEGO_id para que el frontend lo reconozca
        query = "SELECT id, nombre, nivel, horas, juego_id AS JUEGO_id FROM equipo_juego"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                # El cursor DictCursor devuelve diccionarios listos
                equipos = cursor.fetchall()
                
                return jsonify(equipos)
                
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

    # --- RUTA POST (Crear) ---
    if request.method == 'POST':
        data = request.get_json()
        nombre = data.get('nombre')
        nivel = data.get('nivel')
        # Añadido valor predeterminado seguro en caso de que falte
        horas_jugadas = data.get('horas_jugadas', 0) 
        # Leemos el campo que el frontend envía (JUEGO_id)
        id_juego = data.get('JUEGO_id') 
        
        # Validación
        if not nombre or nivel is None or id_juego is None: 
            return jsonify({'error': 'Faltan campos obligatorios (nombre, nivel, JUEGO_id)'}), 400

        # El INSERT usa el nombre de columna real de la DB (id_juego)
        query = "INSERT INTO EQUIPO (nombre, nivel, horas_jugadas, id_juego) VALUES (%s, %s, %s, %s)"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (nombre, nivel, horas_jugadas, id_juego))
                conn.commit()
                return jsonify({'message': 'Equipo creado', 'id': cursor.lastrowid}), 201
        except Exception as e:
            conn.rollback()
            return jsonify({'error': str(e)}), 500
        finally:
            conn.close()

@equipo_bp.route('/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def handle_equipo(id):
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión'}), 500
    
    try:
        # --- RUTA GET (Detalle) ---
        if request.method == 'GET':
            # CORRECCIÓN CLAVE: Usamos AS JUEGO_id
            query = "SELECT id, nombre, nivel, horas_jugadas, id_juego AS JUEGO_id FROM EQUIPO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                # fetchone() devuelve el diccionario listo.
                equipo = cursor.fetchone()
                
                if equipo:
                    return jsonify(equipo) # Devuelve el diccionario formateado
                
                return jsonify({'error': 'Equipo no encontrado'}), 404
        
        # --- RUTA PUT (Actualizar) ---
        if request.method == 'PUT':
            data = request.get_json()
            nombre = data.get('nombre')
            nivel = data.get('nivel')
            horas_jugadas = data.get('horas_jugadas')
            # Leemos el campo que el frontend envía (JUEGO_id)
            id_juego = data.get('JUEGO_id') 
            
            if not nombre or nivel is None or horas_jugadas is None or id_juego is None: 
                return jsonify({'error': 'Faltan campos obligatorios'}), 400

            # El UPDATE usa el nombre de columna real de la DB (id_juego)
            query = "UPDATE EQUIPO SET nombre = %s, nivel = %s, horas_jugadas = %s, id_juego = %s WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (nombre, nivel, horas_jugadas, id_juego, id))
                conn.commit()
                if cursor.rowcount == 0: 
                    return jsonify({'error': 'Equipo no encontrado o sin cambios'}), 404
                return jsonify({'message': 'Equipo actualizado'})
        
        # --- RUTA DELETE (Eliminar) ---
        if request.method == 'DELETE':
            query = "DELETE FROM EQUIPO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (id,))
                conn.commit()
                if cursor.rowcount == 0: 
                    return jsonify({'error': 'Equipo no encontrado'}), 404
                return jsonify({'message': 'Equipo eliminado'})

    except Exception as e:
        if conn: 
            conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        if conn: 
            conn.close()