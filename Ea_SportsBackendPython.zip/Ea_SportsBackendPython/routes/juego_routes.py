from flask import Blueprint, request, jsonify
from models.db import get_db_connection 

# ⭐️ 1. Definición del Blueprint ⭐️
# Esto soluciona el ImportError: cannot import name 'juego_bp'
juego_bp = Blueprint('juegos', __name__)

# --- RUTAS PRINCIPALES ---

@juego_bp.route('/', methods=['GET', 'POST'])
def handle_juegos():
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión a la base de datos'}), 500
    
    # aqui se obtiene el listar juegos
    if request.method == 'GET':
        query = "SELECT id, nombre, estudio_dev,PLATAFORMA_id, tipo FROM JUEGO"
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                juegos = cursor.fetchall()
                
                
                juegos_formateados = []
                for juego in juegos:
                    juegos_formateados.append({
                        'id': juego['id'],
                        'tipo': juego['tipo'],
                        'nombre': juego['nombre'],
                        'PLATAFORMA_id': juego['PLATAFORMA_id'],
                        'estudio_dev': juego['estudio_dev']
                    })
                
                return jsonify(juegos_formateados)
        except Exception as e:
            return jsonify({'error': f'Error al obtener juegos: {str(e)}'}), 500
        finally:
            conn.close()
    
    # ⭐️ CREAR UN JUEGO (POST) ⭐️
    elif request.method == 'POST':
        data = request.get_json()
        
        if not data or 'nombre' not in data or 'genero' not in data:
            return jsonify({'error': 'Nombre y género son requeridos'}), 400
        
        query = """
            INSERT INTO JUEGO (nombre, genero, desarrollador) 
            VALUES (%s, %s, %s)
        """
        
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, (
                    data.get('nombre'),
                    data.get('genero'),
                    data.get('desarrollador', 'Desconocido') # Valor predeterminado
                ))
                conn.commit()
                
                return jsonify({
                    'message': 'Juego creado exitosamente',
                    'id': cursor.lastrowid
                }), 201
        except Exception as e:
            conn.rollback()
            return jsonify({'error': f'Error al crear juego: {str(e)}'}), 500
        finally:
            conn.close()

# aqui estan las rutas con id especifico 

@juego_bp.route('/<int:juego_id>', methods=['GET', 'PUT', 'DELETE'])
def handle_juego_id(juego_id):
    conn = get_db_connection()
    if not conn: 
        return jsonify({'error': 'Fallo en la conexión a la base de datos'}), 500

    try:
        # get para juego en especifico
        if request.method == 'GET':
            query = "SELECT id, nombre, genero, desarrollador FROM JUEGO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (juego_id,))
                juego = cursor.fetchone()
                
                if juego:
                    return jsonify({
                        'id': juego['id'],
                        'nombre': juego['nombre'],
                        'genero': juego['genero'],
                        'desarrollador': juego['desarrollador']
                    })
                else:
                    return jsonify({'error': 'Juego no encontrado'}), 404

        # actualizar juego
        elif request.method == 'PUT':
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Datos de actualización requeridos'}), 400

            query = """
                UPDATE JUEGO 
                SET nombre = %s, genero = %s, desarrollador = %s 
                WHERE id = %s
            """
            with conn.cursor() as cursor:
                cursor.execute(query, (
                    data.get('nombre'),
                    data.get('genero'),
                    data.get('desarrollador'),
                    juego_id
                ))
                conn.commit()
                
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Juego no encontrado para actualizar'}), 404
                
                return jsonify({'message': 'Juego actualizado exitosamente'})

        # delete juego
        elif request.method == 'DELETE':
            query = "DELETE FROM JUEGO WHERE id = %s"
            with conn.cursor() as cursor:
                cursor.execute(query, (juego_id,))
                conn.commit()
                
                if cursor.rowcount == 0:
                    return jsonify({'error': 'Juego no encontrado para eliminar'}), 404
                
                return jsonify({'message': 'Juego eliminado exitosamente'})

    except Exception as e:
        conn.rollback()
        return jsonify({'error': f'Error en la operación: {str(e)}'}), 500
    finally:
        conn.close()